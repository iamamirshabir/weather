import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OktaAuthService } from '@okta/okta-angular';
import { HomeService } from './home.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  weather: any;

  user: any;

  value = 'Dubai';

  username = '';

  userDb: any;

  cityDb: any;

  userLoaded: Promise<boolean>;

  constructor(public oktaAuth: OktaAuthService,private userService: HomeService,
    private route: Router) { }

  ngOnInit(): void {
    this.checkUser();
  }

  changeSearch(s: string){
    this.value=s;
    this.getWeather();
  }
  getUserByEmail(email: string){
     this.userService.getUserByEmail(email).subscribe((res)=>{
      this.userDb = res
      console.log(res);
    })
  }

  getCityByName(name: string){
    this.userService.getCityByName(name).subscribe((res)=>{
      this.cityDb = res;
      console.log(res);
     })
 }

  addCity(name: string):any{
    this.userService.addCity({city_name:name}).subscribe((res)=>{
      
      this.cityDb = res;
      console.log(res);
    })
  }

  addToFav(name: string):void{
    
    this.getCityByName(name);
    
    setTimeout(()=>{
      if(!this.cityDb){
        this.addCity(name);
        }
      this.addToList()
    },3000)
  }
  identify(index, item){
    return item.city_name; 
 }
  async logout(){
    await this.oktaAuth.signOut();
    this.route.navigateByUrl('/');
  }
  addToList(){
    this.userService.addCityToFav(this.userDb.id,this.cityDb.city_id).subscribe((res)=>{
      this.userDb =res;
      console.log(res);
    })
   
  }
  removeFromList(city_id: number){
    this.userService.removeCityToFav(this.userDb.id,city_id).subscribe((res)=>{
      this.userDb =res;
      console.log(res);
    })
   
  }

  checkUser(){
    this.getClaims().then((user)=>{
      this.getUserByEmail(this.user.email);
      if(!this.userDb){
        this.addUser(this.user.email)
      } 
    }
    );
    
  }

  addUser(e: string):void{
    this.userService.addUser({email:e}).subscribe((res)=>{
      console.log(res);
    })
  }

  async getClaims(){
     await this.oktaAuth.getUser().then((res)=>{
      this.user = res;
     });
  }

  getWeather():void{
    this.userService.getWeather(this.value).subscribe((res) =>{
      this.weather = res;
      console.log(res);
    })
  }

}
