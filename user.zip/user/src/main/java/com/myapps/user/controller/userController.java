package com.myapps.user.controller;


import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.myapps.user.model.User;
import com.myapps.user.repository.userRepository;



@RestController
@RequestMapping(value = "/api/user")
public class userController {
	
	@Autowired
	private final userRepository repository;	
	
	
	  public userController(userRepository repository) {
		super();
		this.repository = repository;
	}
	  
	  @GetMapping("/")
	  
	  public
	  List<User> all(){
		  List<User> users = repository.findAll();
		  return users;
	  }
	  
	  @GetMapping("/searchByEmail")

	  public  ResponseEntity<?> getByEmail(@RequestParam(name = "email") String email){
		  Optional<User> optionalUser = repository.findByEmail(email);
		  if (!optionalUser.isPresent()) {
	            return ResponseEntity.unprocessableEntity().build();
	        }
		  return ResponseEntity.ok().body((optionalUser.get()));
	   }
	  
	  @GetMapping("/{id}")

	  public  ResponseEntity<?> getById(@RequestParam(name = "id") Long id){
		  Optional<User> optionalUser = repository.findById(id);
		  if (!optionalUser.isPresent()) {
	            return ResponseEntity.unprocessableEntity().build();
	        }
		  return ResponseEntity.ok().body((optionalUser.get()));
	   }
	  @PostMapping("/")
	  
	  ResponseEntity<?> newCity(@RequestBody User newUser ) {
		  User user = repository.save(newUser);
		  return ResponseEntity.ok(user);
	  }

	  
	  @DeleteMapping("/{id}")
	  
	  void deleteuser(@PathVariable Long id) {
	    repository.deleteById(id);
	  }
}
