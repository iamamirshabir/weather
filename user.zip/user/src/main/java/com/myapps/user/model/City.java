package com.myapps.user.model;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="city",
uniqueConstraints = { 
		@UniqueConstraint(columnNames = "name")})
public class City {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	@NotBlank
	@Column(name="name")
	private String name;
	
	@ManyToMany(fetch = FetchType.EAGER,mappedBy = "likedCities"
)
	Set<User> likes;
	
	public City() {
		super();
	}

	
	public City(@NotBlank String name, Set<User> likes) {
		super();
		this.name = name;
		this.likes = likes;
	}


	@JsonIgnore
	public Set<User> getLikes() {
		return likes;
	}
	public void setLikes(Set<User> likes) {
		this.likes = likes;
	}
	public Long getCity_id() {
		return id;
	}
	public void setCity_id(Long id) {
		this.id = id;
	}
	public String getCity_name() {
		return name;
	}

	public void setCity_name(String name) {
		this.name = name;
	}
	
}	
	