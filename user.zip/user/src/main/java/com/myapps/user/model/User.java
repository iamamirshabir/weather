package com.myapps.user.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;


@Entity
@Table(	name = "users", 
		uniqueConstraints = { 
			@UniqueConstraint(columnNames = "email") 
		})
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank
	@Size(max = 50)
	@Email
	private String email;
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(
	  name = "user_like", 
	  joinColumns = @JoinColumn(name = "user_id"), 
	  inverseJoinColumns = @JoinColumn(name = "city_id"))
	Set<City> likedCities;
	
	public User() {
	}



	public User(Long id, @NotBlank @Size(max = 50) @Email String email, Set<City> likedCities) {
		super();
		this.id = id;
		this.email = email;
		this.likedCities = likedCities;
	}



	public Set<City> getLikedCities() {
		return likedCities;
	}


	public void setLikedCities(Set<City> likedCities) {
		this.likedCities = likedCities;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}