package com.myapps.weatherapi;


import java.net.URI;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriTemplate;

@RestController
@RequestMapping(value = "/api/weather")
public class weatherController {
	
	
	
	
	private static final String WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather?q={city}&APPID={key}";
	
    private final String apiKey = "ff1bc4683fc7325e9c57e586c20cc03e";
	 
    @GetMapping("/")
	public  ResponseEntity<?> getCurrentWeather(@RequestParam(name = "city") String city){
		RestTemplate restTemplate = new RestTemplate();
	        URI url = new UriTemplate(WEATHER_URL).expand(city, apiKey);
	        System.out.println(apiKey);
	        ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);

	        return response;
	    }
	   
	   
	  	  

}
