package com.myapps.user.controller;


import com.myapps.user.model.User;
import com.myapps.user.repository.userRepository;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.codec.multipart.FilePart;
import org.springframework.web.bind.annotation.*;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping(value = "/api/user")
public class userController {
	
	@Autowired
	private final userRepository repository;	
	
	
	  public userController(userRepository repository) {
		super();
		this.repository = repository;
	}
	  
	  @GetMapping("/")
	  
	  public
	  List<User> all(){
		  List<User> users = repository.findAll();
		  return users;
	  }
	  
	  @GetMapping("/searchByEmail")

	  public  ResponseEntity<?> getByEmail(@RequestParam(name = "email") String email){
		  Optional<User> optionalUser = repository.findByEmail(email);
		  if (!optionalUser.isPresent()) {
	            return ResponseEntity.unprocessableEntity().build();
	        }
		  return ResponseEntity.ok().body((optionalUser.get()));
	   }
	  
	  @GetMapping("/{id}")

	  public  ResponseEntity<?> getById(@PathVariable(name = "id") Long id){
		  Optional<User> optionalUser = repository.findById(id);
		  if (!optionalUser.isPresent()) {
	            return ResponseEntity.unprocessableEntity().build();
	        }
		  return ResponseEntity.ok().body((optionalUser.get()));
	   }
	  @PostMapping("/")
	  
	  ResponseEntity<?> newCity(@RequestBody User newUser ) {
		  User user = repository.save(newUser);
		  return ResponseEntity.ok(user);
	  }

	  @PutMapping(value = "/{id}/addProfile", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	  public ResponseEntity<?> uploadImage(@RequestPart("imageFile") FilePart file, @PathVariable(name = "id") Long id) throws IOException {

		  Optional<User> optionalUser = repository.findById(id);
		  if (!optionalUser.isPresent()) {
			  return ResponseEntity.unprocessableEntity().build();
		  }
		  File f = new File("profile.txt");
		  file.transferTo(f);
		  optionalUser.get().setProfilePic(FileUtils.readFileToByteArray(f));

	/*  		file.content().map(
					dataBuffer -> {
						byte[] bytes = new byte[dataBuffer.readableByteCount()];
						dataBuffer.read(bytes);
						//optionalUser.get().setProfilePic(bytes);
						//System.out.println(bytes);
						DataBufferUtils.release(dataBuffer);

						return bytes;
					});*/
		  optionalUser.get().setProfileAdded(true);
		  repository.save(optionalUser.get());
		  return ResponseEntity.ok().build();
	  }

	@DeleteMapping("/{id}")
	  
	  void deleteuser(@PathVariable Long id) {
	    repository.deleteById(id);
	  }
}
