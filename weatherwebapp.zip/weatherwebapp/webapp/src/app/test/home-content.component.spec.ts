import {ComponentFixture, TestBed} from '@angular/core/testing';
import {HomeContentComponent} from '../home-content/home-content.component';
import {OKTA_CONFIG, OktaAuthModule, OktaAuthService} from '@okta/okta-angular';
import {RouterTestingModule} from '@angular/router/testing';
import {HttpClientModule} from '@angular/common/http';

describe('HomeContentComponent', () => {
  let component: HomeContentComponent;
  let fixture: ComponentFixture<HomeContentComponent>;
  let HomeContentService: OktaAuthService;
  const oktaConfig = {
    clientId: '0oa1kbuhrxXXt4iGg5d7',
    issuer: 'https://dev-09035438.okta.com/oauth2/default',
    redirectUri: 'http://localhost:4200/login/callback',
    scopes: ['openid', 'profile', 'email'],
    pkce: true
  };


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OktaAuthModule,RouterTestingModule, HttpClientModule],
      declarations: [ HomeContentComponent ],
      providers: [{provide: OKTA_CONFIG, useValue: oktaConfig}]
    })
    .compileComponents();

  });

  it('should create Home-Content component', () => {
    const fixture = TestBed.createComponent(HomeContentComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it('login() should exists', () => {
    const fixture = TestBed.createComponent(HomeContentComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.login).toBeTruthy();
  });

  it('ngOnInit() should exists', () => {
    const fixture = TestBed.createComponent(HomeContentComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.ngOnInit).toBeTruthy();
  });

});
