import {Injectable} from '@angular/core';
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {catchError} from 'rxjs/internal/operators';
import {map} from 'rxjs/operators';
import {OktaAuthService} from '@okta/okta-angular';
import {Router} from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class HomeService {

  private extractData(res: any): any {
    const body = res;
    return body || {};
  }

  constructor(public oktaAuth: OktaAuthService,private _http: HttpClient, private route: Router) { }
  getUser(user: any):Observable<any>{
    const accessToken = this.oktaAuth.getAccessToken();
     return this._http.post("http://localhost:8080/api/user/",user,{headers: {
      Authorization: 'Bearer ' + accessToken,
    }}).pipe(map(this.extractData), catchError(this.handleError));
  }

  getClaims():Observable<any>{
    const accessToken = this.oktaAuth.getAccessToken();
     return this._http.get("http://localhost:8080/hello",{headers: {
      Authorization: 'Bearer ' + accessToken,
    }}).pipe(map(this.extractData), catchError(this.handleError));
  }
  getUserByEmail(email: string):Observable<any>{
    const accessToken = this.oktaAuth.getAccessToken();
     return this._http.get("http://localhost:8080/api/user/searchByEmail?email="+email,{headers: {
      Authorization: 'Bearer ' + accessToken,
    }}).pipe(map(this.extractData), catchError(this.handleError));
  }

  addUserProfile(selectedFile,name,id: number){
    const accessToken = this.oktaAuth.getAccessToken();
    const uploadImageData = new FormData();
    uploadImageData.append('imageFile', selectedFile, name);
    this._http.put('http://localhost:8080/api/user/'+id+"/addProfile", uploadImageData, { headers: {
      Authorization: 'Bearer ' + accessToken,
    },observe: 'response' })
      .subscribe((response) => {
        if (response.status === 200) {

          this.LoadOnce();
          alert("Image Uplodaded")
           return 'Image uploaded successfully';
        } else {
          this.route.navigate(['']);
          alert("Image not Uplodaded, try again!")
          return 'Image not uploaded successfully';
        }
      }
      );

  }

  getCityByName(name: string):Observable<any>{
    const accessToken = this.oktaAuth.getAccessToken();
     return this._http.get("http://localhost:8080/api/city/searchByName?name="+name,{headers: {
      Authorization: 'Bearer ' + accessToken,
    }}).pipe(map(this.extractData), catchError(this.handleError));
  }

  addCity(city: any):Observable<any>{
    const accessToken = this.oktaAuth.getAccessToken();
     return this._http.post("http://localhost:8080/api/city/",city,{headers: {
      Authorization: 'Bearer ' + accessToken,
    }}).pipe(map(this.extractData), catchError(this.handleError));
  }

  addUser(user: any):Observable<any>{
    const accessToken = this.oktaAuth.getAccessToken();
     return this._http.post("http://localhost:8080/api/user/",user,{headers: {
      Authorization: 'Bearer ' + accessToken,
    }}).pipe(map(this.extractData), catchError(this.handleError));
  }

  addCityToFav(uId: number,city: number):Observable<any>{
    const accessToken = this.oktaAuth.getAccessToken();
     return this._http.get("http://localhost:8080/api/city/addCity?token="+uId+","+city,{headers: {
      Authorization: 'Bearer ' + accessToken,
    }}).pipe(map(this.extractData), catchError(this.handleError));
  }


  getWeather(city: string):Observable<any>{
    const accessToken = this.oktaAuth.getAccessToken();
    return this._http.get("http://localhost:8080/api/weather/?city="+city,{headers: {
      Authorization: 'Bearer ' + accessToken
    }}).pipe(map(this.extractData), catchError(this.handleError));  }






  private handleError(error: HttpErrorResponse): any {
    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred', error.error.message);
    } else {
      console.error(
        'Backend returned code ${error.status}, ' + 'body was: ${error.error}'
      );
    }
    return throwError('Something bad happened; please try again later!');
  }
  LoadOnce()
  {
  window.location.reload();
  }

}
