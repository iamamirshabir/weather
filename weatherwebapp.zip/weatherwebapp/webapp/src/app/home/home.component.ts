import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {OktaAuthService} from '@okta/okta-angular';
import {HomeService} from './home.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  weather: any;

  weather_condition:any;
  user: any;

  value = 'Toronto';

  username = '';

  userDb: any;

  cityDb: any;

  userLoaded: Promise<boolean>;

  selectedFile: File;
  message: string;
  imageName: any;
  imageSrc: any;
  imageValid: boolean = false;




  constructor(public oktaAuth: OktaAuthService,private userService: HomeService,
    private route: Router) {  }



  ngOnInit(): void {
    this.checkUser();

    this.weather = {
      main : {},
      weather : {},
      isDay: true
    };
    this.getWeather()
  }

  public onFileChanged(event) {
    //Select File
    const reader = new FileReader();

    if(event.target.files && event.target.files.length) {
      this.selectedFile = event.target.files[0];

      reader.onload = () => {

        this.imageSrc = reader.result as string;

      };
      reader.readAsDataURL(this.selectedFile);
      console.log(this.selectedFile.size);

      if(this.selectedFile.size > 1000000){
        this.imageValid = false;
        this.message = "Image Size is not valid!"
      }
      else{
        this.imageValid =true;
        this.message = "";
      }


    }  }

     //Gets called when the user clicks on submit to upload the image
  onUpload() {
    console.log(this.selectedFile);
    this.userService.addUserProfile(this.selectedFile,this.selectedFile.name,this.userDb.id);
    this.route.navigate(['']);
  }

  changeSearch(s: string){
    this.value=s;
    this.getWeather();


  }
  getUserByEmail(email: string){
     this.userService.getUserByEmail(email).subscribe((res)=>{
      this.userDb = res

    })
  }

  getCityByName(name: string){
    this.userService.getCityByName(name).subscribe((res)=>{
      this.cityDb = res;



     })

 }

  addCity(name: string):any{
    this.userService.addCity({city_name:name}).subscribe((res)=>{

      this.cityDb = res;

    })
  }

  addToFav(name: string){
    this.userService.getCityByName(name).subscribe((res)=>{
      this.cityDb = res;
        },
        (error)=>{
          this.userService.addCity({city_name:name}).subscribe((res)=>{
          this.cityDb = res;
        },
        (error)=>{},
        ()=>{
          this.userService.addCityToFav(this.userDb.id,this.cityDb.city_id).subscribe((res)=>{
          this.userDb =res;
          })
        })
    },()=>{
    if(this.userDb != undefined){
      this.userService.addCityToFav(this.userDb.id,this.cityDb.city_id).subscribe((res)=>{
        this.userDb = res;
      })
    }
  })
}

  identify(index, item){

    return item.city_name;

 }
  async logout(){
    await this.oktaAuth.signOut();
    this.route.navigateByUrl('/');
  }

  addToList(){
    this.userService.addCityToFav(this.userDb.id,this.cityDb.city_id).subscribe((res)=>{
      this.userDb =res;

    })

  }


  checkUser(){
    this.getClaims().then((user)=>{
      this.getUserByEmail(this.user.email);
      if(!this.userDb){
        this.addUser(this.user.email)
      }
    }
    );

  }

  addUser(e: string):void{
    this.userService.addUser({email:e}).subscribe((res)=>{

    })

  }

  async getClaims(){
     await this.oktaAuth.getUser().then((res)=>{
      this.user = res;

      sessionStorage.setItem('username', this.user.name);

     });

  }

  getWeather():void{
    this.userService.getWeather(this.value).subscribe((res) =>{

        this.setWeatherData(res);
        this.weather = res;


    })
  }

  setWeatherData(data){
    this.weather = data;
    let sunsetTime = new Date(this.weather.sys.sunset * 1000);
    this.weather.sunset_time = sunsetTime.toLocaleTimeString();
    let currentDate = new Date();
    this.weather.isDay = (currentDate.getTime() < sunsetTime.getTime());
    console.log(this.weather.weather)
    for (var key in this.weather.weather) {
      this.weather_condition=this.weather.weather[key];
  }


  }

  LoadOnce()
  {
  window.location.reload();
  }


}
