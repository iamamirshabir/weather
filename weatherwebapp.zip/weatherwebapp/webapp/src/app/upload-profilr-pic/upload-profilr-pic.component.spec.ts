import {ComponentFixture, TestBed} from '@angular/core/testing';

import {UploadProfilrPicComponent} from './upload-profilr-pic.component';

describe('UploadProfilrPicComponent', () => {
  let component: UploadProfilrPicComponent;
  let fixture: ComponentFixture<UploadProfilrPicComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UploadProfilrPicComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadProfilrPicComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
