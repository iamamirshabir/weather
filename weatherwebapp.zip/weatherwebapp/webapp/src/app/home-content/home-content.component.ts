import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {OktaAuthService} from '@okta/okta-angular';


@Component({
  selector: 'app-home-content',
  templateUrl: './home-content.component.html',
  styleUrls: ['./home-content.component.css']
})
export class HomeContentComponent implements OnInit {


  constructor(public oktaAuth: OktaAuthService,private route: Router) { }

  ngOnInit(): void {}


  async login() {

    await this.oktaAuth.signInWithRedirect({

      originalUri: '/'

    });

  }
}
