import {Injector, NgModule} from '@angular/core';
import {Router, RouterModule, Routes} from '@angular/router';
import {OktaAuthGuard, OktaAuthService, OktaCallbackComponent} from '@okta/okta-angular';
import {AboutusComponent} from './aboutus/aboutus.component';
import {HomeContentComponent} from './home-content/home-content.component';
import {HomeComponent} from './home/home.component';
import {UploadProfilrPicComponent} from './upload-profilr-pic/upload-profilr-pic.component';

const CALLBACK_PATH = 'login/callback';

const routes: Routes = [
  {
    path: CALLBACK_PATH,
    component: OktaCallbackComponent
  },


  {path:'home',component:HomeComponent,
  canActivate: [ OktaAuthGuard ],
  data: {
    onAuthRequired
  }},

  {path:'',component:HomeContentComponent},
  {path:'AboutUs',component:AboutusComponent},
  {path:'UploadProfilePic',component:UploadProfilrPicComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

export function onAuthRequired(oktaAuth: OktaAuthService, injector: Injector) {
  const router = injector.get(Router);

  // Redirect the user to your custom login page
  router.navigate(['/']);
}
