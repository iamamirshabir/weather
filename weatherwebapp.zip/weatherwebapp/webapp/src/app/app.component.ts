import {Component} from '@angular/core';
import {Router} from '@angular/router';
import {OktaAuthService} from '@okta/okta-angular';
import {HomeService} from './home/home.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  isAuthenticated: boolean;
  user: any;
  userplaceholder:any;
  userDb: any;
  cityDb: any;
  title: any='Weather App';

  retrievedImage: any;
  base64Data: any;
  retrieveResonse: any;
  imageset:any;

  constructor(public oktaAuth: OktaAuthService,private route: Router,public homeservice:HomeService) {
    // Subscribe to authentication state changes
    this.oktaAuth.$authenticationState.subscribe(
      (isAuthenticated: boolean) => this.isAuthenticated = isAuthenticated
    );
  }

  async ngOnInit() {
    this.checkUser();
    this.isAuthenticated = await this.oktaAuth.isAuthenticated();
      if(this.isAuthenticated == true){
        this.getUser();

      }
  }

  LoadOnce()
  {
  window.location.reload();
  }

  checkUser(){
    this.getClaims().then((user)=>{
      this.getUserByEmail(this.user.email);
      if(!this.userDb){
        this.addUser(this.user.email)
      } else{
        this.LoadOnce()
      }
    }
    );

  }

  addUser(e: string):void{
    this.homeservice.addUser({email:e}).subscribe((res)=>{
    })

  }


  getUserByEmail(email: string){
    this.homeservice.getUserByEmail(email).subscribe((res)=>{
     this.userDb = res

   })
 }
  getUser(){
    this.oktaAuth.getUser().then((u)=>{
      this.homeservice.getUserByEmail(u.email).subscribe( (uDb)=>{
        this.userDb = uDb;
        if(uDb.profileAdded == true){
          this.base64Data = uDb.profilePic;
          this.retrievedImage = 'data:image/png;base64,' + this.base64Data;
        }
      })
    })
  }


  async getClaims(){
    await this.oktaAuth.getUser().then((res)=>{
     this.user = res;


    });

 }

  async login() {
    await this.oktaAuth.signInWithRedirect({

      originalUri: '/'

    });

  }
  async logout(){
    sessionStorage.removeItem('username');
    await this.oktaAuth.signOut();

    this.route.navigateByUrl('/');
  }




}
function indexOf(arg0: string): any {
  throw new Error('Function not implemented.');
}


