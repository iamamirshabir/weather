package com.myapps.city.controller;

import com.myapps.city.model.City;
import com.myapps.city.model.User;
import com.myapps.city.repository.cityRepository;
import com.myapps.city.repository.userRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping(value = "/api/city")
public class cityController {
	
	@Autowired
	private final cityRepository repository;
	
	@Autowired
	private final userRepository user_repository;
	
	

	public cityController(cityRepository repository, userRepository user_repository) {
		super();
		this.repository = repository;
		this.user_repository = user_repository;
	}
	
	
	  @GetMapping("/")
	  public List<City> all(){
		  List<City> cities = repository.findAll();
		  return cities;
	  }
	  
	  @GetMapping("/{id}")
	  public  ResponseEntity<?> getById(@RequestParam(name = "id") Long id){
		  Optional<City> optionalCity = repository.findById(id);
		  if (!optionalCity.isPresent()) {
	            return ResponseEntity.unprocessableEntity().build();
	        }
		  return ResponseEntity.ok().body((optionalCity.get()));
	   }

	  @GetMapping("/searchByName")
	  public  ResponseEntity<?> getByName(@RequestParam(name = "name") String name){
		  Optional<City> optionalCity = repository.findByName(name);
		  if (!optionalCity.isPresent()) {
	            return ResponseEntity.unprocessableEntity().build();
	        }
		  return ResponseEntity.ok().body((optionalCity.get()));
	   }
	  
	  @PostMapping("/")
	  ResponseEntity<?> newCity(@RequestBody City newCity ) {
		  City city = repository.save(newCity);
		  return ResponseEntity.ok(city);
	  }
	  
	  @GetMapping("/addCity")
	  ResponseEntity<?> newCity(@RequestParam(name = "token") String token) {
		Optional<User> optionalUser = user_repository.findById(Long.parseLong(token.split(",")[0]));
		 if (!optionalUser.isPresent()) {
	            return ResponseEntity.badRequest().build();
	        }
		 
		 Optional<City> optionalCity = repository.findById(Long.parseLong(token.split(",")[1]));
			 if (!optionalCity.isPresent()) {
	            return ResponseEntity.badRequest().build();
	        }
				optionalUser.get().getLikedCities().add(optionalCity.get());
				optionalCity.get().getLikes().add(optionalUser.get());
				repository.save(optionalCity.get());
				user_repository.save(optionalUser.get());

		  return ResponseEntity.of(optionalUser);
	   
	  }
	  
	  @GetMapping("/removeCity")
	  ResponseEntity<?> removeCity(@RequestParam(name = "token") String token) {
		Optional<User> optionalUser = user_repository.findById(Long.parseLong(token.split(",")[0]));
		 if (!optionalUser.isPresent()) {
	            return ResponseEntity.unprocessableEntity().build();
	        }

		 Optional<City> optionalCity = repository.findById(Long.parseLong(token.split(",")[1]));
			 if (!optionalCity.isPresent()) {
	            return ResponseEntity.unprocessableEntity().build();
	        }
				optionalUser.get().getLikedCities().remove(optionalCity.get());
				optionalCity.get().getLikes().remove(optionalUser.get());
				repository.save(optionalCity.get());
				user_repository.save(optionalUser.get());

		  return ResponseEntity.of(optionalUser);

	  }
	  
	  @PutMapping("/{id}")
	  ResponseEntity<?> replaceCity(@RequestBody City newcity, @PathVariable Long id) {
		  City updatedCity = repository.findById(id)
				  .map(city ->{
					  city.setCity_name(newcity.getCity_name());
					  return repository.save(city);
				  })
				  .orElseGet(() ->{
					  newcity.setCity_id(id);
					  return repository.save(newcity);
				  });
		  
		  return ResponseEntity.ok(updatedCity);
				  
					 
	  }
	  
//	  @DeleteMapping("/{id}")
//
//	  void deletecity(@PathVariable Long id) {
//	    repository.deleteById(id);
//	  }
//

}
