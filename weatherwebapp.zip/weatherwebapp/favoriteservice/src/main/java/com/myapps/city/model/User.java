package com.myapps.city.model;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.Set;


@Entity
@Table(	name = "users",
		uniqueConstraints = {
				@UniqueConstraint(columnNames = "email")
		})
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private boolean profileAdded;
	@Lob
	private byte[] profilePic;

	@NotBlank
	@Size(max = 50)
	@Email
	private String email;

	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(
			name = "user_like",
			joinColumns = @JoinColumn(name = "user_id"),
			inverseJoinColumns = @JoinColumn(name = "city_id"))
	Set<City> likedCities;

	public User() {
	}

	public User(boolean profileAdded, byte[] profilePic, @NotBlank @Size(max = 50) @Email String email) {
		this.profileAdded = profileAdded;
		this.profilePic = profilePic;
		this.email = email;
	}

	public boolean isProfileAdded() {
		return profileAdded;
	}

	public void setProfileAdded(boolean profileAdded) {
		this.profileAdded = profileAdded;
	}

	public byte[] getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(byte[] profilePic) {
		this.profilePic = profilePic;
	}

	public Set<City> getLikedCities() {
		return likedCities;
	}


	public void setLikedCities(Set<City> likedCities) {
		this.likedCities = likedCities;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}