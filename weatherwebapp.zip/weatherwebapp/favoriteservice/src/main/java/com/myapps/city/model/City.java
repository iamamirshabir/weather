package com.myapps.city.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.util.Set;

@Entity
@Table(name="city")
public class City {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="id")
	private Long id;
	
	@NotBlank
	@Column(name="name")
	private String name;
	
	@ManyToMany(fetch = FetchType.EAGER,mappedBy = "likedCities")
	Set<User> likes;
	
	public City() {
		super();
	}

	
	public City(@NotBlank String name) {
		super();
		this.name = name;
	}


	@JsonIgnore
	public Set<User> getLikes() {
		return likes;
	}
	public void setLikes(Set<User> likes) {
		this.likes = likes;
	}
	public Long getCity_id() {
		return id;
	}
	public void setCity_id(Long id) {
		this.id = id;
	}
	public String getCity_name() {
		return name;
	}

	public void setCity_name(String name) {
		this.name = name;
	}
	
}	
	