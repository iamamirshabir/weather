package com.myapps.city.repository;

import com.myapps.city.model.City;
import com.myapps.city.model.User;
import org.junit.After;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
@RunWith(SpringRunner.class)
@DataJpaTest
class cityRepositoryTest {
    @Autowired
    private cityRepository city;
    @Autowired
    private userRepository user;
    @After
    public void tearDown() throws Exception {
        city.deleteAll();
        user.deleteAll();
    }
    @Test
    public void shouldSaveAndFetchCityFromItsName() throws Exception {
        City dubai = new City("dubai");
        city.save(dubai);
        Optional<City> maybeDubai = city.findByName("dubai");
        assertEquals("dubai",dubai.getCity_name());
    }
    @Test
    public void shouldBeAbleToGetSpecificUsersFavouriteCities() throws Exception {
        Set<City> citylist = new HashSet<>();
        byte[] profilePic = new byte[1024];
        City city1 = new City("dubai");
        City city2 = new City("London");
        City city3 = new City("Montreal");
        citylist.add(city1);
        citylist.add(city2);
        citylist.add(city3);
        User peter = new User(false,profilePic,"ibrahim@gmail.com");
        user.save(peter);
        peter.setLikedCities(citylist);
        assertEquals(3,peter.getLikedCities().size());
    }
}