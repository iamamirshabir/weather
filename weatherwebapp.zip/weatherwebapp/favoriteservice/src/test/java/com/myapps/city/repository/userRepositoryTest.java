package com.myapps.city.repository;

import com.myapps.city.model.City;
import com.myapps.city.model.User;
import org.junit.After;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
@RunWith(SpringRunner.class)
@DataJpaTest
class userRepositoryTest {
        @Autowired
        private userRepository user;
        @After
        public void tearDown() throws Exception {
            user.deleteAll();
        }
        @Test
        public void shouldSaveAndFetchPersonFromHisEmail() throws Exception {
            Set<City> cities = new HashSet<>();
            byte []profilePic = new byte[1024];
            User peter = new User(false,profilePic,"ibrahim@gmail.com");
            user.save(peter);
            Optional<User> maybePeter = user.findByEmail("ibrahim@gmail.com");
            assertEquals("ibrahim@gmail.com",peter.getEmail());
        }
        @Test
        public void shouldBeAbleToGetUsersId() throws Exception {
            Set<City> dubai = new HashSet<>();
            byte []profilePic = new byte[1024];
            User peter = new User(false,profilePic,"ibrahim@gmail.com");
            user.save(peter);
            assertEquals(2,peter.getId());

        }
}