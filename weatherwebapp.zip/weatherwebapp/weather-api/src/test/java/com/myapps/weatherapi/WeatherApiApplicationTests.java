package com.myapps.weatherapi;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.HttpClientBuilder;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;

@RunWith(SpringRunner.class)
class WeatherApiApplicationTests {
	String apiKey = "ff1bc4683fc7325e9c57e586c20cc03e";
	String name ="montreal" ;
	String WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather?q="+name+"&APPID="+apiKey;
	@Test
	public void givenOpenWeatherApiURlWithAPIKeyCheckIfTheApiStatusIsOkGivenAValidCityName() throws IOException {
		// Given
		HttpUriRequest request = new HttpGet(this.WEATHER_URL);
		System.out.println(this.name);
		System.out.println(WEATHER_URL);
		// When
		HttpResponse httpResponse = HttpClientBuilder.create().build().execute(request);
		assertEquals(200,httpResponse.getStatusLine().getStatusCode());
	}
	@Test
	public void givenOpenWeatherApiURlWithAPIKeyCheckIfTheApiStatusIsBadRequestForNotValidCityName()throws IOException {
		name ="Potato" ;
		apiKey = "ff1bc4683fc7325e9c57e586c20cc03e";
		WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather?q="+name+"&APPID="+apiKey;
		// Given
		HttpUriRequest request = new HttpGet(WEATHER_URL);
		// When
		HttpResponse httpResponse = HttpClientBuilder.create().build().execute(request);
		assertEquals(404,httpResponse.getStatusLine().getStatusCode());
	}
}
