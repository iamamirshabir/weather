#!/bin/bash

mvn clean package -DskipTests

docker build -t gateway:latest .

docker build -t discovery:latest .

docker build -t weatherapi:latest .

docker build -t userservice:latest .

docker build -t favoriteservice:latest .

cd api-gateway
cd favoriteservice
cd discovery-server
cd userservice
cd weather-api