package com.example.apigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.security.oauth2.gateway.TokenRelayGatewayFilterFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@EnableEurekaClient
public class ApiGatewayApplication {

    public static void main(String[] args) {

        SpringApplication.run(ApiGatewayApplication.class, args);
    }

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder,
                                           TokenRelayGatewayFilterFactory filterFactory) {
        return builder.routes()
                .route("user-service",r -> r.path("/api/user/**")
                        .filters(f -> f.filter(filterFactory.apply()))
                        .uri("lb://user-service"))
                .route("user-service",r -> r.path("/api/user/searchByEmail")
                        .filters(f -> f.filter(filterFactory.apply()))
                        .uri("lb://user-service"))
                .route("user-service",r -> r.path("/api/user/addProfile/**")
                        .filters(f -> f.filter(filterFactory.apply()))
                        .uri("lb://user-service"))
                .route("city-service",r -> r.path("/api/city")
                        .filters(f -> f.filter(filterFactory.apply()))
                        .uri("lb://city-service"))
                .route("city-service",r -> r.path("/api/city/addCity")
                        .filters(f -> f.filter(filterFactory.apply()))
                        .uri("lb://city-service"))
                .route("city-service",r -> r.path("/api/city/removeCity")
                        .filters(f -> f.filter(filterFactory.apply()))
                        .uri("lb://city-service"))
                .route("city-service",r -> r.path("/api/city/searchByName")
                        .filters(f -> f.filter(filterFactory.apply()))
                        .uri("lb://city-service"))
                .route("weather-service",r -> r.path("/api/weather")
                        .filters(f->f.setResponseHeader("Access-Control-Allow-Origin", "*"))
                        .uri("lb://weather-service"))
                .build();
    }
    
    @RestController
    class ExampleRestController {
        @GetMapping("/hello")
        ResponseEntity<?> helloUser(@AuthenticationPrincipal OidcUser user) {
            return ResponseEntity.ok(user.getAttributes());
        }
        
        @GetMapping("/profile")
        ResponseEntity<?> profileUser(@AuthenticationPrincipal OidcUser user) {
            return ResponseEntity.ok(user);
        }
    }
}
