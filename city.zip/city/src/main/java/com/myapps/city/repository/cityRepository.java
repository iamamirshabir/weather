package com.myapps.city.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.myapps.city.model.City;

public interface cityRepository extends JpaRepository<City, Long>{

	Optional<City> findByName(String name);
	
}
